Zapret2Wizard 0.18.24 (autonomous bundle, aarch64_cortex-a53)

Установка:
  tar -xzf <этот файл> -C /tmp
  cd /tmp/zapret2wizard-* && sh install.sh

Ничего не скачивается: все зависимости внутри.
