#!/bin/sh
# Установка Zapret2Wizard из автономного бандла (без интернета).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
echo "=== Zapret2Wizard bundle installer ==="

if [ ! -d "$HERE/payload" ]; then
    echo "  распаковываю payload..."
    tar -xf "$HERE/payload.tar" -C "$HERE"
fi

# Не перетираем существующий конфиг со стратегиями при обновлении.
if [ -f /etc/config/zapret2wizard ] && [ -f "$HERE/payload/etc/config/zapret2wizard" ]; then
    cp -f /etc/config/zapret2wizard /tmp/zapret2wizard.cfg.keep
    rm -f "$HERE/payload/etc/config/zapret2wizard"
    echo "  существующий конфиг сохранён"
fi

mkdir -p /usr/bin /etc/init.d /etc/config /usr/share/blockcheckw \
         /usr/share/luci/menu.d /usr/share/rpcd/acl.d \
         /usr/share/zapret2wizard /etc/zapret2wizard/ipset \
         /www/luci-static/resources/view/blockcheckw /opt/zapret2/nfq2

cp -a "$HERE/payload/." /

chmod +x /usr/bin/blockcheckw-helper /usr/bin/circular-builder.lua \
         /usr/bin/nfqws2 /usr/bin/blockcheckw /etc/init.d/zapret2wizard \
         /usr/share/zapret2wizard/uci2config 2>/dev/null || true
chmod 644 /www/luci-static/resources/view/blockcheckw/main.js 2>/dev/null || true

[ -e /usr/bin/zapret2wizard ] || ln -sf /usr/bin/blockcheckw-helper /usr/bin/zapret2wizard
[ -e /opt/zapret2/nfq2/nfqws2 ] || ln -sf /usr/bin/nfqws2 /opt/zapret2/nfq2/nfqws2

rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache* 2>/dev/null || true
/etc/init.d/rpcd restart >/dev/null 2>&1 || true
/etc/init.d/uhttpd restart >/dev/null 2>&1 || true

/etc/init.d/zapret2wizard enable >/dev/null 2>&1 || true
/etc/init.d/zapret2wizard restart >/dev/null 2>&1 || true
sleep 2

echo "  установлено. Проверка:"
/usr/bin/blockcheckw-helper doctor 2>/dev/null | head -14 || true
echo
echo "Откройте LuCI → Службы → Zapret2Wizard и запустите поиск."
